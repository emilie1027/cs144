package edu.ucla.cs.cs144;

public class BidResult {
	public String userID, rating;
	public String location, country;
	public String time, amount;
}
