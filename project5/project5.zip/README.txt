Project5
1.(4)->(5),(5)->(6)
2.Save Buy_Price with other information of item in SESSION rather than COOKIES or in HTML FORM to avoid illegal altering Buy_Price on the user sides. Since SESSION saves on both server side and user side, however, COOKIE only saves on user side.